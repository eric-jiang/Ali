'use client';


import { Auth0Provider } from "@auth0/auth0-react";
import styles from "./page.module.css";
import Header from "@/components/header";
import WeatherSearch from "@/components/weatherSearch";

export default function Home() {

  return (
    <Auth0Provider
      domain="dev-7lslgpa2v3lkbxb1.us.auth0.com"
      clientId="FMhypDVl3AQ6FYG8ZMlD1m3F2sx5CyTV"
      authorizationParams={{
        redirect_uri: "http://localhost:3000",
        audience: "http://localhost:8080/weather",
        scope: "get:weather"

      }}
    >
      <main className={styles.main}>
        <Header></Header>
        <WeatherSearch></WeatherSearch>
      </main>
    </Auth0Provider>
  );
}
