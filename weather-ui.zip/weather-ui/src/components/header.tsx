import React from "react";
import { useAuth0 } from "@auth0/auth0-react";
import LogoutButton from "./logout";
import LoginButton from "./login";

const Header = () => {
    const { user, isAuthenticated } = useAuth0();

    return <div style={{ backgroundColor: "rgb(240,240,240)", padding: "10px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>{!isAuthenticated && <LoginButton></LoginButton>}
            {isAuthenticated && <LogoutButton></LogoutButton>}
            {isAuthenticated && <span>{user?.email}</span>}</div>

        <div>
            <h3>Weather Application</h3>
        </div>
        <div></div>

    </div>;
};

export default Header;