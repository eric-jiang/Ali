import React from "react";
import { useAuth0 } from "@auth0/auth0-react";

const LogoutButton = () => {
    const { logout } = useAuth0();

    return (
        <button style={{ cursor: "pointer", border: "none", borderRadius: "5px", backgroundColor: "rgb(255,80,80)", color: "white", width: "80px", height: "30px" }} onClick={() => logout({ logoutParams: { returnTo: window.location.origin } })}>
            Log Out
        </button>
    );
};

export default LogoutButton;