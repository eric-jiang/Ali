import React, { useEffect, useState } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import { fetchData } from "./api";


interface Data {
    currentWeather: {
        description: string;
        min: number;
        max: number;
        date: string;
    };
    nextFourDays: any
}

const fetchDataAsync = async (city: string, params: {}) => {

    try {
        const result = await fetchData<Data>(`http://localhost:8080/weather?city=${city}`, params);
        return result;
    } catch (error) {
        // Handle error
        alert("error fetching data from server")
    }
};

const WeatherSearch = () => {
    const [data, setData] = useState<Data | null>(null);
    const { isAuthenticated } = useAuth0();

    return <div>
        {isAuthenticated && <WeatherSearchComponent data={data} onSearch={(data: Data) => setData(data)}></WeatherSearchComponent>
        }

    </div >;
};

interface WeatherSearchComponentProps {
    data: Data | null;
    onSearch: (response: Data) => void
}


const WeatherSearchComponent = ({ data, onSearch }: WeatherSearchComponentProps) => {
    const [city, setCity] = useState("Melbourne");
    const [token, setToken] = useState("");
    const { getAccessTokenSilently } = useAuth0();
    const [threshold, setThreshold] = useState(20);

    useEffect(() => {
        const getToken = async () => {
            try {
                const accessToken = await getAccessTokenSilently({
                    authorizationParams: {
                        audience: `http://localhost:8080/weather`,
                        scope: "get:weather",
                    },
                });
                setToken(accessToken);
            } catch (error) {
                // Handle error
                alert("error fetching data from server")
            }
        }
        getToken();
    }, [getAccessTokenSilently])


    const handleCityInputChange = (e) => setCity(e.target.value);
    const handleTempratureThresholdChange = (e) => setThreshold(e.target.value);

    const searchCityWeather = () => {
        fetchDataAsync(city, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        })
            .then((response) => { onSearch(response) })
            .catch((error) => { console.log(error) })
    }

    return <div style={{ textAlign: "center", width: "550px" }}>
        <div style={{ margin: "10px" }}>
            <label style={{}}>City: </label>
            <input style={{ width: "120px", height: "30px", marginLeft: "20px" }} value={city} onChange={handleCityInputChange} />
        </div>
        <div style={{ margin: "10px" }}>
            <label>Max Temperature threshold: </label>
            <input style={{ width: "50px", height: "30px", marginLeft: "20px" }} type="number" value={threshold} onChange={handleTempratureThresholdChange}></input>
        </div>
        <button style={{ cursor: "pointer", border: "none", borderRadius: "5px", backgroundColor: "rgb(50,150,255)", color: "white", height: "30px", width: "120px" }} onClick={() => searchCityWeather()}>show weather</button>

        {data && <>
            <h3>currnt weather</h3>
            <p>{data.currentWeather.description} , <span style={{ color: "blue" }}>{data.currentWeather.min}</span> , <span style={{ color: "red" }}>{data.currentWeather.max}</span>
                {threshold < data.currentWeather.max && <span style={{ color: "red", fontSize: "20px", marginLeft: "20px" }}> * TOO HOT</span>}</p>
            <h3>3-Hourly Next 4 days forecast</h3>
            {data.nextFourDays.map(function (item, i) {
                return <p key={i}>{item.date}, {item.description} , <span style={{ color: "blue" }}>{item.min}</span> , <span style={{ color: "red" }}>{item.max}</span>
                    {threshold < item.max && <span style={{ color: "red", fontSize: "20px", marginLeft: "20px" }}> * TOO HOT</span>}
                </p>
            })}
        </>}

    </div>;
}

export default WeatherSearch;