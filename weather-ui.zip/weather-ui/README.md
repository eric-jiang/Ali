### Description
This is a Next.js frontend application for the Weather Service. 
Node version v21.7.3 and npm version 10.5.0 used for this project.
It can run by the following command:
```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

### User Management
User management is handled by Autho0. test user:
- Username: user1@testcompany.com
- password: test123!@#

Only one user is created for now.

### TODOs
- More proper css to be added using Styled component library
- Validation on city name field
- Showing user info
- Making the page responsive
- Loading to be added to the landing page and when user click the show weather button
- Add tests using Mocha and Cypress
- Get the max temperature threshold from backend
