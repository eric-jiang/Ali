### Description
Weather Service provides an endpoint for the frontend client to query the current weather of an Australia cities and also forecast for the next 4 days. 
It uses OpenMapWeather free api version 2.5 to do so.


### Assumptions and Decisions
- Application uses Auth0 to authenticate incoming API calls. So, calling the API from any place other than the frontend app requires getting the token from the authentication server and attaching it to every request to the backend. 
- Application security only allows frontend from http://localhost:3000 to make api calls
- Application does not have any persistence as of now. So, all the users management is handled by the Authentication Provider.
- Application only validate the given city name to not be empty. Wrong city name causes Server Error.
- To reduce the number of calls to the OpenWeatherApi endpoint, a caching mechanism is implemented which keep the response of each query for 24 hours in memory, so a new request for the same city name does not result in having two queries to the OpenWeatherApi.

### Technologies
- Java 11
- Spring Boot 2.4.3
- Gradle 7.3
- Caffeine to implement the caching mechanism
- Lombok to auto generate boilerplate code
- Spock + groovy for the unit test
- Jococo for test coverage

### Project Packages
- [application.config](src/main/java/com/vg/weatherservice/application/config) directory to maintain the configs of the application
- [application.exception](src/main/java/com/vg/weatherservice/application/exception) directory to maintain the exception classes of the application
- [application.service](src/main/java/com/vg/weatherservice/application/service) directory to maintain the interfaces of the services
- [infrastructure.api](src/main/java/com/vg/weatherservice/infrastructure/api) directory to maintain infrastructure code of the application API

### Build and Run
Java 11 should be installed before running the following commands.
The project can be built by running the following command:
~~~
./gradlew clean build
~~~
It runs all the unit tests as well.

To run the application the following command can be run:
~~~
./gradlew bootRun
~~~

### Test Coverage
test coverage settings is located in [coverage.gradle](coverage.gradle) and is set as below:
~~~
'instruction': 75,
'branch'     : 20,
'line'       : 70,
'complexity' : 45,
'method'     : 73,
'class'      : 75
~~~


### To Be Improved

- Higher code coverage, needs to add more unit tests as well
- Integration Test
- DB and Persistence Layer to Store user related settings
- Using libraries like **Mapstruct** to covert the DTOs