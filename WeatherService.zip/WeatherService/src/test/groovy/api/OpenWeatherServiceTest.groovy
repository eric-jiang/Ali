package com.vg.weatherservice.infrastructure.api

import com.vg.weatherservice.application.config.ConfigProperties
import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherForecastResponse
import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherResponse
import com.vg.weatherservice.infrastructure.api.dto.WeatherResponse
import com.vg.weatherservice.infrastructure.api.factory.WeatherResponseFactory
import org.springframework.web.client.RestTemplate
import spock.lang.Specification

class OpenWeatherServiceTest extends Specification {

    private OpenWeatherService service
    private RestTemplate restTemplate
    private ConfigProperties properties
    private WeatherResponseFactory factory

    def setup() {
        restTemplate = Mock(RestTemplate.class);
        properties = Mock(ConfigProperties.class);
        factory = Mock(WeatherResponseFactory)
        service = new OpenWeatherService(restTemplate, properties, factory);
    }

    def "getWeather should return weather on successful query"() {
        given:
        def city = "melbourne"

        // Mock current weather response
        def currentWeatherResponse = Mock(OpenWeatherResponse)
        def currentWeather = Mock(OpenWeatherResponse.Weather)
        currentWeather.description >> "cloudy"
        def main = OpenWeatherResponse.Main.builder().tempMax(20).tempMin(10).build()
        currentWeather.description >> "cloudy"
        currentWeatherResponse.weather >> [currentWeather]
        currentWeatherResponse.main >> main


        // Mock forecast weather response
        def forecastWeatherResponse = Mock(OpenWeatherForecastResponse)
        def nextWeatherResponse = Mock(OpenWeatherResponse)
        def nextWeather = Mock(OpenWeatherResponse.Weather)
        currentWeather.description >> "cloudy"
        def nextMain = OpenWeatherResponse.Main.builder().tempMax(20).tempMin(10).build()
        nextWeather.description >> "cloudy"
        nextWeatherResponse.weather >> [currentWeather]
        nextWeatherResponse.main >> nextMain
        forecastWeatherResponse.list >> [nextWeatherResponse]

        //Mock factory result
        def weatherResponse = Mock(WeatherResponse)


        when:
        def weather = service.getWeather(city)


        then:
        1 * properties.getCurrentWeatherUrl() >> "test-url"
        2 * properties.getApiKey()
        1 * restTemplate.getForObject(_, OpenWeatherResponse.class) >> currentWeatherResponse
        1 * properties.getForecastWeatherUrl() >> "test-url"
        1 * restTemplate.getForObject(_, OpenWeatherForecastResponse.class) >> forecastWeatherResponse
        1 * factory.toWeatherResponse(_, _) >> weatherResponse

        and:
        assert weather == weatherResponse
    }


}
