package com.vg.weatherservice.infrastructure.api


import com.vg.weatherservice.application.service.WeatherService
import com.vg.weatherservice.infrastructure.api.dto.WeatherResponse
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import spock.lang.Specification

class WeatherRestControllerTest extends Specification {


    private WeatherRestController restController
    private WeatherService weatherService

    def setup() {
        weatherService = Mock(WeatherService.class)
        restController = new WeatherRestController(weatherService)
    }

    def "getWeather_returnOk_onSuccessfulQuery"() {
        given:
        def city = "melbourne"
        weatherService.getWeather(city) >> Mock(WeatherResponse)

        when:
        ResponseEntity<WeatherResponse> response = restController.getWeather(city)

        then:
        assert response.getStatusCode() == HttpStatus.OK;
    }

//    def "getWeather should throw WeatherNotFoundException when weatherService throw exception"() {
//        given:
//        weatherService.getWeather(_) >> new WeatherNotFoundException("")
//
//        when:
//        restController.getWeather("adfdafaf")
//
//        then:
//        thrown(WeatherNotFoundException)
//    }
}
