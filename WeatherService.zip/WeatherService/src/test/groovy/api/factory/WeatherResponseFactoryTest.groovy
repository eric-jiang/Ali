package api.factory


import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherForecastResponse
import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherResponse
import com.vg.weatherservice.infrastructure.api.dto.WeatherResponse
import com.vg.weatherservice.infrastructure.api.factory.WeatherResponseFactory
import spock.lang.Specification

class WeatherResponseFactoryTest extends Specification {

    WeatherResponseFactory factory

    def setup() {
        factory = new WeatherResponseFactory()
    }

    def "should convert OpenMap CurrentWeather and ForecastWeather to WeatherResponse"() {
        given:
        def currentWeather = OpenWeatherResponse.builder()
                .weather(Arrays.asList(OpenWeatherResponse.Weather.builder().description("Sunny").build()))
                .main(OpenWeatherResponse.Main.builder().tempMin(14.5).tempMax(18.5).build()).build()
        def forecastResponse = OpenWeatherForecastResponse.builder()
                .list([currentWeather])
                .build()

        when:
        def weatherResponse = factory.toWeatherResponse(currentWeather, forecastResponse)

        then:
        assert weatherResponse.currentWeather.description == currentWeather.weather[0].description
        assert weatherResponse.currentWeather.max == currentWeather.main.tempMax
        assert weatherResponse.currentWeather.min == currentWeather.main.tempMin
        assert weatherResponse.nextFourDays[0].description == forecastResponse.list[0].weather[0].description
        assert weatherResponse.nextFourDays[0].max == forecastResponse.list[0].main.tempMax
        assert weatherResponse.nextFourDays[0].min == forecastResponse.list[0].main.tempMin
    }
}
