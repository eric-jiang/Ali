package com.vg.weatherservice.infrastructure.api.factory;

import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherForecastResponse;
import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherResponse;
import com.vg.weatherservice.infrastructure.api.dto.WeatherResponse;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
public class WeatherResponseFactory {

    public WeatherResponse toWeatherResponse(OpenWeatherResponse openWeatherResponse, OpenWeatherForecastResponse forecastResponse) {
        return WeatherResponse.builder()
                .currentWeather(WeatherResponse.WeatherResponseDetails.builder()
                        .description(openWeatherResponse.getWeather().get(0).getDescription())
                        .min(openWeatherResponse.getMain().getTempMin())
                        .max(openWeatherResponse.getMain().getTempMax())
                        .build())
                .nextFourDays(forecastResponse.getList()
                        .stream().map(item ->
                                WeatherResponse.WeatherResponseDetails.builder()
                                        .description(item.getWeather().get(0).getDescription())
                                        .max(item.getMain().getTempMax())
                                        .min(item.getMain().getTempMin())
                                        .date(item.getDateString()).build()).collect(Collectors.toList()))
                .build();
    }
}
