package com.vg.weatherservice.application.service;

import com.vg.weatherservice.infrastructure.api.dto.WeatherResponse;

public interface WeatherService {

    WeatherResponse getWeather(String city);

}
