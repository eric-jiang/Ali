package com.vg.weatherservice.infrastructure.api.dto;

import lombok.Builder;

import java.io.Serializable;
import java.util.List;

@Builder
public class WeatherResponse implements Serializable {

    public WeatherResponseDetails currentWeather;
    public List<WeatherResponseDetails> nextFourDays;

    @Builder
    public static class WeatherResponseDetails {
        public String description;
        public double max;
        public double min;
        public String date;

        public WeatherResponseDetails(String description, double max, double min, String date) {
            this.description = description;
            this.max = max;
            this.min = min;
            this.date = date;
        }

        public WeatherResponseDetails() {
        }
    }

    public WeatherResponse(WeatherResponseDetails currentWeather, List<WeatherResponseDetails> nextFourDays) {
        this.currentWeather = currentWeather;
        this.nextFourDays = nextFourDays;
    }

    public WeatherResponse() {
    }
}
