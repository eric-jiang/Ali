package com.vg.weatherservice.infrastructure.api;

import com.vg.weatherservice.application.config.ConfigProperties;
import com.vg.weatherservice.application.exception.WeatherNotFoundException;
import com.vg.weatherservice.application.service.WeatherService;
import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherForecastResponse;
import com.vg.weatherservice.infrastructure.api.dto.OpenWeatherResponse;
import com.vg.weatherservice.infrastructure.api.dto.WeatherResponse;
import com.vg.weatherservice.infrastructure.api.factory.WeatherResponseFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class OpenWeatherService implements WeatherService {

    private final RestTemplate restTemplate;
    private final ConfigProperties properties;
    private final WeatherResponseFactory factory;

    @PostConstruct
    public void init() {
        restTemplate.setErrorHandler(new RestTemplateResponseErrorHandler());
    }

    @Override
    @Cacheable(cacheNames = "weathers", key = "#city", condition = "#city != null && !#city.isEmpty()", unless = "#result == null")
    public WeatherResponse getWeather(String city) {
        log.debug("Cache missed for city {}", city);
        var currentWeather = getCurrentWeather(city);
        var forecastWeather = getForecastWeather(city);

        if (!validateCurrentWeatherResponse(currentWeather)) {
            throw new WeatherNotFoundException("Weather not found in the currentWeather: " + currentWeather);
        }
        return factory.toWeatherResponse(currentWeather, forecastWeather);
    }

    private static boolean validateCurrentWeatherResponse(OpenWeatherResponse currentWeather) {
        return Objects.nonNull(currentWeather) && Objects.nonNull(currentWeather.getWeather()) && !currentWeather.getWeather().isEmpty();
    }

    private OpenWeatherForecastResponse getForecastWeather(String city) {
        return this.restTemplate
                .getForObject(String.format(properties.getForecastWeatherUrl(), city, "AU", properties.getApiKey()), OpenWeatherForecastResponse.class);
    }

    private OpenWeatherResponse getCurrentWeather(String city) {
        return this.restTemplate
                .getForObject(String.format(properties.getCurrentWeatherUrl(), city, "AU", properties.getApiKey()), OpenWeatherResponse.class);
    }


}