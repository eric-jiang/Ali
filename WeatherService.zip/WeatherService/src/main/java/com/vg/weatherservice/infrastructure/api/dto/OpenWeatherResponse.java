package com.vg.weatherservice.infrastructure.api.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.jackson.Jacksonized;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Jacksonized
public class OpenWeatherResponse implements Serializable {

    private String base;
    private long visibility;
    private long dt;

    @JsonProperty("dt_txt")
    private String dateString;

    private long timezone;
    private long id;
    private String name;
    private long cod;
    private Coord coord;
    private List<Weather> weather;
    private Main main;
    private Wind wind;
    private Clouds clouds;
    private Sys sys;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Coord {
        private long lon;
        private long lat;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Weather {
        private long id;
        private String main;
        private String description;
        private String icon;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Main {
        private long temp;
        private long feelsLike;

        @JsonProperty("temp_min")
        private double tempMin;

        @JsonProperty("temp_max")
        private double tempMax;
        private long pressure;
        private long humidity;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Wind {
        private double speed;
        private double deg;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Clouds {
        private long clouds;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Sys {
        private long type;
        private long id;
        private String country;
        private long sunrise;
        private long sunset;
    }
}